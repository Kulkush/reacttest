import { useSelector, useDispatch } from 'react-redux';
import { todoToggled } from './feature/todos/todosSlice';

export default  function TodoList() {
    const todos = useSelector((state) => state.todos);
    const dispatch = useDispatch();

    return (
        <ul>
            {todos.map((t) => (
                <li
                    key={t.id}
                    onClick={() => dispatch(todoToggled(t.id))}
                    style={{ textDecoration: t.completed ? 'line-through' : 'none', cursor: 'pointer' }}
                >
                    {t.text}
                </li>
            ))}
        </ul>
    );
}