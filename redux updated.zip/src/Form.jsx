import { useSelector, useDispatch } from 'react-redux';
import { updateField, submitForm, resetForm } from './feature/formSlice';

const Form = () => {
    const formData = useSelector((state) => state.form.data);
    const submitted = useSelector((state) => state.form.submitted);
    const dispatch = useDispatch();

    const handleChange = (e) => {
        dispatch(updateField({ field: e.target.name, value: e.target.value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        dispatch(submitForm());
    };

    return (
        <div style={{ maxWidth: '400px', margin: '50px auto', padding: '20px' }}>
            <h2>Registration Form</h2>
            <form onSubmit={handleSubmit}>
                <input
                    name="name"
                    placeholder="Name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    style={{ display: 'block', margin: '10px 0', padding: '10px', width: '100%' }}
                />
                <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    style={{ display: 'block', margin: '10px 0', padding: '10px', width: '100%' }}
                />
                <input
                    type="password"
                    name="password"
                    placeholder="Password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                    style={{ display: 'block', margin: '10px 0', padding: '10px', width: '100%' }}
                />
                <button type="submit" style={{ padding: '10px 20px', background: '#007bff', color: 'white', border: 'none' }}>
                    Submit
                </button>
                <button
                    type="button"
                    onClick={() => dispatch(resetForm())}
                    style={{ padding: '10px 20px', marginLeft: '10px', background: '#6c757d', color: 'white', border: 'none' }}
                >
                    Reset
                </button>
            </form>
            {submitted && (
                <div style={{ marginTop: '20px', padding: '15px', background: '#d4edda', border: '1px solid #c3e6cb' }}>
                    <h3>Submitted Data:</h3>
                    <pre>{JSON.stringify(formData, null, 2)}</pre>
                </div>
            )}
        </div>
    );
};

export default Form;
