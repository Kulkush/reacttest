import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchUsers } from "./feature/usersSlice";

export default function Users() {
    const { items, status, error } = useSelector((s) => s.users);
    const dispatch = useDispatch();

    useEffect(() => {
        if (status === "idle") dispatch(fetchUsers());
    }, [status, dispatch]);

    if (status === "loading") return <p>Loading...</p>;
    if (status === "failed") return <p>Error: {error}</p>;

    return (
        <div>
            <h2>Users</h2>
            <ul>
                {items.map((u) => (
                    <li key={u.id}>{u.name}</li>
                ))}
            </ul>
        </div>
    );
}