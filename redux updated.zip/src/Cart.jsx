import { useSelector, useDispatch } from "react-redux";
import { removeFromCart, changeQty, clearCart } from "./feature/cartSlice";

export default function Cart() {
    const items = useSelector((s) => s.cart.items);
    const dispatch = useDispatch();

    const total = items.reduce(
        (sum, item) => sum + item.price * item.qty,
        0
    );

    return (
        <div>
            <h2>Cart</h2>
            {items.length === 0 && <p>Cart is empty</p>}
            {items.map((item) => (
                <div key={item.id}>
                    {item.title} (${item.price}) 
                    <input
                        type="number"
                        min="1"
                        value={item.qty}
                        onChange={(e) =>
                            dispatch(
                                changeQty({ id: item.id, qty: Number(e.target.value) || 1 })
                            )
                        }
                    />
                    <button onClick={() => dispatch(removeFromCart(item.id))}>
                        Remove
                    </button>
                </div>
            ))}
            <hr />
            <p>Total: ${total.toFixed(2)}</p>
            <button onClick={() => dispatch(clearCart())}>Clear</button>
        </div>
    );
}