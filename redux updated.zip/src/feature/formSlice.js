// src/features/formSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    data: { name: '', email: '', password: '' },
    submitted: false,
};

const formSlice = createSlice({
    name: 'form',
    initialState,
    reducers: {
        updateField: (state, action) => {
            state.data = { ...state.data, [action.payload.field]: action.payload.value };
        },
        submitForm: (state) => {
            state.submitted = true;
        },
        resetForm: (state) => {
            state.data = { name: '', email: '', password: '' };
            state.submitted = false;
        },
    },
});

export const { updateField, submitForm, resetForm } = formSlice.actions;
export default formSlice.reducer;
