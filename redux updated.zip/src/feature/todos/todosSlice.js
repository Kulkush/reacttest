import { createSlice, nanoid } from '@reduxjs/toolkit';

const todosSlice = createSlice({
    name: 'todos',
    initialState: [],
    reducers: {
        todoAdded: {
            reducer(state, action) {
                state.push(action.payload);
            },
            prepare(text) {
                return {
                    payload: {
                        id: nanoid(),
                        text,
                        completed: false,
                    },
                };
            },
        },
        todoToggled(state, action) {
            const todo = state.find((t) => t.id === action.payload);
            if (todo) {
                todo.completed = !todo.completed;
            }
        },
    },
});

export const { todoAdded, todoToggled } = todosSlice.actions;
export default todosSlice.reducer;

/*
Redux Toolkit (RTK) simplifies ID generation by re-exporting
nanoid (a small, secure, URL-friendly unique ID generator) for use in your application code.

It is used internally by createAsyncThunk and can be easily incorporated into your own slices and actions. 

Usage in Redux Toolkit
You can import and use nanoid in two primary ways within a Redux application: 
1. Inside a prepare callback within createSlice 
This is the recommended approach for generating IDs when creating new entities (like a todo item). 

The prepare callback allows you to customize the action's payload and ensures the ID is generated when the action is created, before it reaches the reducer
*/